const section = document.querySelector(".vote-result-percentage-section");


async function createPartiCards() {
    const respData = await getPartier();
    console.log(respData);


    for (let i = 0; i < respData.length; i++) {
        const item = document.createElement("div");
        item.classList.add("parti-card");

        const partiName = document.createElement("h3");
        partiName.classList.add("parti-name");
        partiName.innerHTML = respData[i].name;

        const partiPercentage = document.createElement("h5");
        partiPercentage.classList.add("parti-percentage");
        partiPercentage.innerHTML = "Stemmeprocent:   " + respData[i].stemmeProcent;

        const partiVotesInTotal = document.createElement("h5");
        partiVotesInTotal.classList.add("parti-votes-in-total");
        partiVotesInTotal.innerHTML = "Stemmer i alt:    " + respData[i].stemmeTal;

        item.appendChild(partiName);
        item.appendChild(partiPercentage);
        item.appendChild(partiVotesInTotal);
        section.appendChild(item);
    }
    
}

createPartiCards();