const showKandidaterBtn = document.querySelector(".show-kandidater-btn");
const kandidatTable = document.querySelector(".kandidat-table");
const sortKandidatesByPartiBtn = document.querySelector(".sort-kandidater-by-parti-btn")
const kandidatTableSection = document.querySelector(".kandidat-table-section");
const findPartiInput = document.querySelector(".find-parti-input");
const findPartiBtn = document.querySelector(".find-parti-btn");
const newKandidatForm = document.querySelector(".ny-kandidat-form");
const newKandidatBtn = document.querySelector(".ny-kandidat-btn");
const newKandidatNameInput = document.querySelector(".ny-kandidat-name-input");
const newKandidatStemmeAntalInput = document.querySelector(".ny-kandidat-stemmer-input");
const partiDropdown = document.querySelector(".parti-dropdown");

const url = `http://localhost:8080`;


async function getPartier() {
    const resp = await fetch(url + "/parti");
    const respData = await resp.json();
    return respData;

}

async function getKandidater() {
    const resp = await fetch(url + "/kandidater");
    const respData = await resp.json();
    addKandidatToRow(respData);
}

async function getKandidaterSorteret() {
    const resp = await fetch(url + "/kandidater/sorteret");
    const respData = await resp.json();
    addKandidatToRow(respData);

}

async function getKandidaterByPartiName(name) {
    const resp = await fetch(url + "/kandidat/" + `${name}`);
    //console.log(resp);
    const respData = await resp.json();
    console.log(respData);
    addKandidatToRow(respData);

}


function updateKandidat(data) {
    fetch(url + "/kandidat/update", {
        method: "PUT",
        body: JSON.stringify(data),
        headers: { "Content-type": "application/json; charset=UTF-8" }
    })
}


async function newKandidat(data) {
    await fetch(url + "/kandidat", {
        method: "POST",
        body: JSON.stringify(data),
        headers: { "Content-type": "application/json; charset=UTF-8" }
    })
}

async function newParti(data){
    await fetch(url + "/parti", {
        method: "POST",
        body: JSON.stringify(data),
        headers: { "Content-type": "application/json; charset=UTF-8" }
    })
}

async function deleteKandidat(id) {
    await fetch(url + "/kandidat/" + id, {
        method: "DELETE",
        headers: { "Content-type": "application/json; charset=UTF-8" }
    })
}

function kandidatTableHeadlines() {
    let rowCount = kandidatTable.rows.length;
    let row = kandidatTable.insertRow(rowCount);

    row.insertCell(0).innerHTML = `Id`;
    row.insertCell(1).innerHTML = `Name`;
    row.insertCell(2).innerHTML = `Stemmer`;
    row.insertCell(3).innerHTML = `Parti`;
    row.insertCell(4).innerHTML = `Delete Kandidat`;
    row.insertCell(5).innerHTML = `Update Kandidat`;
}

function deleteRow(rowObj) {
    let row = rowObj.parentNode.parentNode;
    let table = row.parentNode;
    
    deleteKandidat(row.childNodes[0].firstChild.nodeValue);
    table.removeChild(row);
}


function addKandidatToRow(respData) {
    for (let i = 0; i < respData.length; i++) {
        let kandidat = {
            kandidatId: respData[i].kandidatId,
            name: respData[i].name,
            stemmer: respData[i].stemmer,
            parti: respData[i].parti
        }
        console.log(kandidat);
        let rowCount = kandidatTable.rows.length;
        let row = kandidatTable.insertRow(rowCount);

        row.insertCell(0).innerHTML = kandidat.kandidatId;
        row.insertCell(1).innerHTML = `<p contentEditable="true">${kandidat.name}</p>`;
        row.insertCell(2).innerHTML = `<p contentEditable="true">${kandidat.stemmer}</p>`;
        row.insertCell(3).innerHTML = kandidat.parti.name;
        row.insertCell(4).innerHTML = `<a onclick="deleteRow(this)"> <button type="button" class="delete-kandidat-btn">Slet kandidat</button></a>`;
        row.insertCell(5).innerHTML = `<a onclick="saveRow(this)"> <button type="button" class="update-kandidat-btn">Update kandidat</button></a>`;

    }

}
function saveRow(rowObj) {
    let row = rowObj.parentNode.parentNode;

    const kandidatName = row.childNodes[1].firstChild.textContent;
    const kandidatStemmer = row.childNodes[2].firstChild.textContent;

    let data = {
        kandidatId: row.childNodes[0].firstChild.textContent,
        name: kandidatName,
        stemmer: kandidatStemmer,
        parti: {
            partiId: "",
            name: "",
            stemmeTal: "",
            stemmeProcent: ""
        }

    }
    console.log(data);
    updateKandidat(data);
}

showKandidaterBtn.addEventListener("click", (e) => {
    e.preventDefault();
    if (kandidatTable.innerHTML != "") {
        kandidatTable.innerHTML = "";
        kandidatTableHeadlines();
        getKandidater();
    }
    
});

sortKandidatesByPartiBtn.addEventListener("click", (e) => {
    e.preventDefault();
    if (kandidatTable.innerHTML != "") {
        kandidatTable.innerHTML = "";
        kandidatTableHeadlines();
        getKandidaterSorteret();
    }
});


findPartiBtn.addEventListener("click", async (e) => {
    e.preventDefault();
    if (kandidatTable.innerHTML != "") {
        kandidatTable.innerHTML = "";
        kandidatTableHeadlines();
       await getKandidaterByPartiName(findPartiInput.value);
    }
});

newKandidatBtn.addEventListener("click", async (e) => {
    e.preventDefault();
    const respData = await getPartier();
    console.log(partiDropdown.value);

    let data = {
        name: newKandidatNameInput.value,
        stemmer: newKandidatStemmeAntalInput.value,
        parti: respData[parseInt(partiDropdown.value) - 1]
    }
    console.log(data);
    if (data) {
        newKandidat(data);

    }






})


kandidatTableHeadlines();


const socialDemokratiet = { partiId: 0,name:"Social Demokratiet", partiBogstav: "	A	", stemmeTal: 853, stemmeProcent: 24.1 }
const radikaleVenstre = { partiId: 1,name:"Radikale Venstre", partiBogstav: "	B	", stemmeTal: 118, stemmeProcent: 3.0 }
const detKonservativeFolkeparti = { partiId: 2,name: "Det konservative Folkeparti", partiBogstav: "	C	", stemmeTal: 550, stemmeProcent: 13.8 }
const sfSocialistiskFolkeparti = {partiId: 3, name: "SF-Socialistisk Folkeparti", partiBogstav: "	F	", stemmeTal: 244, stemmeProcent: 6.1 }
const ærøICentrum = {partiId: 4, name: "Ærø i Centrum", partiBogstav: "	M	", stemmeTal: 279, stemmeProcent: 7.0 }
const danskFolkeparti = {partiId: 5, name: "Dansk Folkeparti", partiBogstav: "	O	", stemmeTal: 288, stemmeProcent: 7.2 }
const ærøPlus = {partiId: 6, name: "ÆrøPlus", partiBogstav: "	P	", stemmeTal: 836, stemmeProcent: 21.0 }
const venstreDanmarksLiberaleParti = {partiId: 7, name: "Venstre, Danmarks Liberale Parti", partiBogstav: "	V	", stemmeTal: 378, stemmeProcent: 9.5 }
const ærøsFremtid = {partiId: 8, name: "Ærøs Fremtid", partiBogstav: "	Æ	", stemmeTal: 435, stemmeProcent: 10.9 }




const kandidater = [{ name: "	Peter Hansted	", stemmer: 426, parti: socialDemokratiet },
{ name: "	Karin Thumilaire	", stemmer: 55, parti: socialDemokratiet },
{ name: "	Hans Peter Rønn Bolding	", stemmer: 158, parti: socialDemokratiet },
{ name: "	Johannes Renneberg	", stemmer: 48, parti: socialDemokratiet },
{ name: "	Jørgen Roos	", stemmer: 12, parti: socialDemokratiet },
{ name: "	Leslie Rabuchin	", stemmer: 4, parti: socialDemokratiet },
{ name: "	Ole Wej Petersen	", stemmer: 44, parti: socialDemokratiet },
{ name: "	Morten Brixtofte Petersen	", stemmer: 64, parti: radikaleVenstre },
{ name: "	Michael Brande	", stemmer: 19, parti: radikaleVenstre },
{ name: "	Anne Balslev	", stemmer: 6, parti: radikaleVenstre },
{ name: "	Erik Jørs	", stemmer: 8, parti: radikaleVenstre },
{ name: "	Lars Rimfalk Jensen	", stemmer: 2, parti: radikaleVenstre },
{ name: "	Mads Boeburg Hansen	", stemmer: 255, parti: detKonservativeFolkeparti },
{ name: "	Søren Laxy	", stemmer: 139, parti: detKonservativeFolkeparti },
{ name: "	Leo Holm	", stemmer: 61, parti: detKonservativeFolkeparti },
{ name: "	Charlotte Aabye	", stemmer: 14, parti: detKonservativeFolkeparti },
{ name: "	Frank Thorsted	", stemmer: 20, parti: detKonservativeFolkeparti },
{ name: "	Thomas Wang Larsen	", stemmer: 13, parti: detKonservativeFolkeparti },
{ name: "	Minna Henriksen	", stemmer: 129, parti: sfSocialistiskFolkeparti },
{ name: "	Jette Roust Iversen	", stemmer: 26, parti: sfSocialistiskFolkeparti },
{ name: "	Line Strandgaard	", stemmer: 37, parti: sfSocialistiskFolkeparti },
{ name: "	Heidi Priebe Beck	", stemmer: 6, parti: sfSocialistiskFolkeparti },
{ name: "	Jens Weiss	", stemmer: 239, parti: ærøICentrum },
{ name: "	Paul Erik Düring Pedersen	", stemmer: 15, parti: ærøICentrum },
{ name: "	Preben T. Jørgensen	", stemmer: 0, parti: ærøICentrum },
{ name: "	Frank Varsnæs	", stemmer: 0, parti: ærøICentrum },
{ name: "	Gorm Truelsen	", stemmer: 2, parti: ærøICentrum },
{ name: "	Gitte Bolt	", stemmer: 4, parti: ærøICentrum },
{ name: "	Flemming Boye	", stemmer: 109, parti: danskFolkeparti },
{ name: "	Bente Friis Andersen	", stemmer: 106, parti: danskFolkeparti },
{ name: "	Inger M. Ziegler	", stemmer: 21, parti: danskFolkeparti },
{ name: "	Anette Kristensen	", stemmer: 13, parti: danskFolkeparti },
{ name: "	Inga Blom Thomas	", stemmer: 600, parti: ærøPlus },
{ name: "	Carl Jørgen Heide	", stemmer: 110, parti: ærøPlus },
{ name: "	Knud Borck	", stemmer: 41, parti: ærøPlus },
{ name: "	Susanne Brøndum	", stemmer: 15, parti: ærøPlus },
{ name: "	Klaus Fynsk Norup	", stemmer: 20, parti: ærøPlus },
{ name: "	Lennart L. Mogensen	", stemmer: 109, parti: venstreDanmarksLiberaleParti },
{ name: "	Iza Alfredsen	", stemmer: 134, parti: venstreDanmarksLiberaleParti },
{ name: "	Peter Noltenius	", stemmer: 28, parti: venstreDanmarksLiberaleParti },
{ name: "	Bjarne Nissen	", stemmer: 44, parti: venstreDanmarksLiberaleParti },
{ name: "	Lisbeth Lumby Rasmussen	", stemmer: 10, parti: venstreDanmarksLiberaleParti },
{ name: "	Bente Christensen	", stemmer: 6, parti: venstreDanmarksLiberaleParti },
{ name: "	Bent Juul Sørensen	", stemmer: 319, parti: ærøsFremtid },
{ name: "	Inger-Marie Albertsen	", stemmer: 47, parti: ærøsFremtid },
{ name: "	Morten Aunsborg	", stemmer: 16, parti: ærøsFremtid },
{ name: "	Ole Gilberg	", stemmer: 15, parti: ærøsFremtid },
{ name: "	Birger Dovald Petersen	", stemmer: 4, parti: ærøsFremtid },
{ name: "	Lasse Kjærgaard Larsen	", stemmer: 11, parti: ærøsFremtid }]


function addPartier(socialDemokratiet,radikaleVenstre,detKonservativeFolkeparti,sfSocialistiskFolkeparti,ærøICentrum,
    danskFolkeparti,ærøPlus,venstreDanmarksLiberaleParti,ærøsFremtid) {
    newParti(socialDemokratiet);
    newParti(radikaleVenstre);
    newParti(detKonservativeFolkeparti);
    newParti(sfSocialistiskFolkeparti);
    newParti(ærøICentrum);
    newParti(danskFolkeparti);
    newParti(ærøPlus);
    newParti(venstreDanmarksLiberaleParti);
    newParti(ærøsFremtid);
}

function addKandidater(kandidater) {
    for (i = 0; i < kandidater.length; i++) {
        newKandidat(kandidater[i]);
    }
}

function CallMeForInitialData(){
addPartier(socialDemokratiet,radikaleVenstre,detKonservativeFolkeparti,sfSocialistiskFolkeparti,ærøICentrum,
    danskFolkeparti,ærøPlus,venstreDanmarksLiberaleParti,ærøsFremtid);
addKandidater(kandidater);

}


