package com.example.eksamen24timer.RESTController;


import com.example.eksamen24timer.Model.Kandidat;
import com.example.eksamen24timer.Model.Parti;
import com.example.eksamen24timer.Repository.PartiRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
public class PartiRESTController {

    @Autowired
    PartiRepository partiRepository;

    @GetMapping("/parti")
    public List<Parti> getPartier(){
        return partiRepository.findAll();
    }

    @PostMapping(value = "/parti", consumes = "application/json")
    public ResponseEntity<Parti> addParti(@RequestBody Parti parti){
        partiRepository.save(parti);
        return new ResponseEntity<>(parti, HttpStatus.CREATED);
    }
}
