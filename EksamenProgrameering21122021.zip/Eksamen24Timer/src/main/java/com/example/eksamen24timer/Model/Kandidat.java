package com.example.eksamen24timer.Model;


import lombok.Generated;

import javax.persistence.*;
import java.util.Objects;

@Entity
public class Kandidat {

    @Id
    @GeneratedValue
    private int kandidatId;
    private String name;
    private int stemmer;

    @ManyToOne
    @JoinColumn(name = "partiId")
    private Parti parti;




    public int getKandidatId() {
        return kandidatId;
    }

    public void setKandidatId(int kandidatId) {
        this.kandidatId = kandidatId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getStemmer() {
        return stemmer;
    }

    public void setStemmer(int stemmer) {
        this.stemmer = stemmer;
    }

    public Parti getParti() {
        return parti;
    }

    public void setParti(Parti parti) {
        this.parti = parti;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Kandidat kandidat = (Kandidat) o;
        return kandidatId == kandidat.kandidatId;
    }

    @Override
    public int hashCode() {
        return Objects.hash(kandidatId);
    }
}
