package com.example.eksamen24timer.RESTController;

import com.example.eksamen24timer.Model.Kandidat;
import com.example.eksamen24timer.Repository.KandidatRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@CrossOrigin
public class KandidatRESTController {

    @Autowired
    KandidatRepository kandidatRepository;

    @GetMapping("/kandidater")
    public List<Kandidat> getAlleKandidater(){
        return kandidatRepository.findAll();
    }

    @GetMapping("/kandidat/{partiName}")
    public List<Kandidat> getKandidatByParti(@PathVariable String partiName){
        return kandidatRepository.findKandidatByPartiName(partiName);
    }

    @GetMapping("/kandidater/sorteret")
    public List<Kandidat> getKandidatSortedByParti (){
        return kandidatRepository.findAllByOrderByPartiDesc();
    }

    @PostMapping(value = "/kandidat", consumes = "application/json")
    public ResponseEntity<Kandidat> addKandidat(@RequestBody Kandidat kandidat){
        kandidatRepository.save(kandidat);
        return new ResponseEntity<>(kandidat, HttpStatus.CREATED);
    }

    @DeleteMapping("/kandidat/{id}")
    public ResponseEntity<Kandidat> deleteKandidat(@PathVariable int id){
        kandidatRepository.deleteById(id);
        return new ResponseEntity<Kandidat>(HttpStatus.OK);
    }

    @PutMapping(value = "/kandidat/update", consumes = "application/json")
    public ResponseEntity<Kandidat> updateKandidat(@RequestBody Kandidat kandidat){
        Optional<Kandidat> data = kandidatRepository.findById(kandidat.getKandidatId());
        if (data.isPresent()){
            Kandidat updatedKandidat = data.get();
            updatedKandidat.setName(kandidat.getName());
            updatedKandidat.setStemmer(kandidat.getStemmer());
            kandidatRepository.save(updatedKandidat);
        }
        return new ResponseEntity<>(kandidat, HttpStatus.OK);
    }
}
