package com.example.eksamen24timer.Repository;

import com.example.eksamen24timer.Model.Kandidat;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface KandidatRepository extends JpaRepository<Kandidat, Integer> {
    List<Kandidat> findKandidatByPartiName(String partiName);
    List<Kandidat> findAllByOrderByPartiDesc();

}
