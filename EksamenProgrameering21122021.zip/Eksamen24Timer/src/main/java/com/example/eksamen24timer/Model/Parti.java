package com.example.eksamen24timer.Model;


import com.fasterxml.jackson.annotation.JsonBackReference;

import javax.persistence.*;
import java.util.*;


@Entity
public class Parti {

    @Id
    private int partiId;
    private String name;
    private String partiBogstav;
    private int stemmeTal;
    private double stemmeProcent;


    @OneToMany
    @JoinColumn(name = "partiId")
    @JsonBackReference
    private Set<Kandidat> kandidater = new HashSet<>();





    public int getPartiId() {
        return partiId;
    }

    public void setPartiId(int partiId) {
        this.partiId = partiId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPartiBogstav() {
        return partiBogstav;
    }

    public void setPartiBogstav(String partiBogstav) {
        this.partiBogstav = partiBogstav;
    }

    public int getStemmeTal() {
        return stemmeTal;
    }

    public void setStemmeTal(int stemmeTal) {
        this.stemmeTal = stemmeTal;
    }

    public double getStemmeProcent() {
        return stemmeProcent;
    }

    public void setStemmeProcent(double stemmeProcent) {
        this.stemmeProcent = stemmeProcent;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Parti parti = (Parti) o;
        return partiId == parti.partiId;
    }

    @Override
    public int hashCode() {
        return Objects.hash(partiId);
    }
}
