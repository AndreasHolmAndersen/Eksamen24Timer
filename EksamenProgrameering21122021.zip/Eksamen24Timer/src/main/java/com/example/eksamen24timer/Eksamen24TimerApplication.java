package com.example.eksamen24timer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Eksamen24TimerApplication {

    public static void main(String[] args) {
        SpringApplication.run(Eksamen24TimerApplication.class, args);
    }

}
